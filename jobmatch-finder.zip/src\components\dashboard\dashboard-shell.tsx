"use client";

import { FormEvent, useMemo, useState } from "react";
import { Bookmark, BriefcaseBusiness, Clock3, LayoutGrid, List, Search, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { formatCurrencyRange } from "@/lib/utils";
import type { ParsedResume, RankedJob, SessionUser } from "@/types";

type DashboardShellProps = {
  user: SessionUser;
  resume: ParsedResume | null;
  initialSavedJobs: Array<{
    id: string;
    title: string;
    company: string;
    location: string;
    source: string;
    applyUrl: string;
  }>;
  initialSavedSearches: Array<{
    id: string;
    name: string;
    alertsEnabled: boolean;
  }>;
  initialHistory: Array<{
    id: string;
    createdAt: string;
    resultsCount: number;
    desiredTitle: string;
    country: string;
  }>;
};

export function DashboardShell({
  user,
  resume,
  initialSavedJobs,
  initialSavedSearches,
  initialHistory
}: DashboardShellProps) {
  const [results, setResults] = useState<RankedJob[]>([]);
  const [savedJobs, setSavedJobs] = useState(initialSavedJobs);
  const [savedSearches, setSavedSearches] = useState(initialSavedSearches);
  const [lastSearchPayload, setLastSearchPayload] = useState<Record<string, FormDataEntryValue>>({});
  const [view, setView] = useState<"cards" | "table">("cards");
  const [sortBy, setSortBy] = useState<"best-match" | "newest" | "salary">("best-match");
  const [status, setStatus] = useState<string | null>(null);
  const [selectedJob, setSelectedJob] = useState<RankedJob | null>(null);

  const sortedResults = useMemo(() => {
    const next = [...results];

    if (sortBy === "newest") {
      return next.sort((a, b) => new Date(b.postedDate ?? "").getTime() - new Date(a.postedDate ?? "").getTime());
    }

    if (sortBy === "salary") {
      return next.sort((a, b) => (b.salaryMax ?? 0) - (a.salaryMax ?? 0));
    }

    return next.sort((a, b) => b.matchScore - a.matchScore);
  }, [results, sortBy]);

  const resumeSuggestions = useMemo(() => {
    if (!resume || !selectedJob) {
      return {
        summary:
          "Upload a resume and click a result to see targeted keyword and wording suggestions for that role.",
        missingSkills: [] as string[],
        wording: [
          "Open with a crisp summary that names your target role.",
          "Quantify outcomes to make experience bullets stronger."
        ]
      };
    }

    return {
      summary: `For ${selectedJob.title}, emphasize ${selectedJob.keywords.slice(0, 3).join(", ")} near the top of your resume.`,
      missingSkills: selectedJob.missingKeywords,
      wording: [
        "Use outcome-driven bullets with action verbs.",
        "Mirror the job's exact terminology where it truthfully applies.",
        "Promote your most relevant project or employer higher in the experience section."
      ]
    };
  }, [resume, selectedJob]);

  async function handleSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("Searching jobs...");
    const formData = new FormData(event.currentTarget);
    const payload = Object.fromEntries(formData.entries());
    setLastSearchPayload(payload);

    const response = await fetch("/api/jobs/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (!response.ok) {
      setStatus(data.error ?? "Search failed.");
      return;
    }

    setResults(data.results);
    setSelectedJob(data.results[0] ?? null);
    setStatus(`Found ${data.results.length} jobs.`);
  }

  async function handleResumeUpload(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("Uploading resume...");
    const formData = new FormData(event.currentTarget);

    const response = await fetch("/api/resumes/upload", {
      method: "POST",
      body: formData
    });

    const data = await response.json();
    setStatus(response.ok ? "Resume uploaded. Refresh to see parsed data." : data.error ?? "Upload failed.");
  }

  async function saveJob(job: RankedJob) {
    const response = await fetch("/api/saved-jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(job)
    });

    const data = await response.json();

    if (!response.ok) {
      setStatus(data.error ?? "Unable to save job.");
      return;
    }

    setSavedJobs((current) => [
      {
        id: data.savedJob.id,
        title: data.savedJob.title,
        company: data.savedJob.company,
        location: data.savedJob.location,
        source: data.savedJob.source,
        applyUrl: data.savedJob.applyUrl
      },
      ...current
    ]);
    setStatus("Job saved.");
  }

  async function removeSavedJob(id: string) {
    const response = await fetch(`/api/saved-jobs?id=${id}`, {
      method: "DELETE"
    });

    if (response.ok) {
      setSavedJobs((current) => current.filter((job) => job.id !== id));
      setStatus("Saved job removed.");
    }
  }

  async function saveSearch() {
    const payload = {
      name: `Search ${new Date().toLocaleDateString()}`,
      alertsEnabled: true,
      alertFrequency: "DAILY",
      querySnapshot: lastSearchPayload
    };

    const response = await fetch("/api/saved-searches", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();

    if (!response.ok) {
      setStatus(data.error ?? "Could not save search.");
      return;
    }

    setSavedSearches((current) => [data.savedSearch, ...current]);
    setStatus("Saved search created with alerts enabled.");
  }

  return (
    <div className="space-y-6">
      <section className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
        <div className="glass-panel rounded-[2rem] p-6">
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="eyebrow">Dashboard</span>
              <h1 className="mt-4 font-[family-name:var(--font-display)] text-3xl font-bold text-slate-950">
                Welcome, {user.name}
              </h1>
              <p className="mt-2 max-w-2xl text-sm leading-7 text-slate-600">
                Search jobs with structured filters, rank them against your resume, and save the strongest leads.
              </p>
            </div>
            <form action="/api/auth/logout" method="POST">
              <Button variant="secondary">Log out</Button>
            </form>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="rounded-3xl bg-slate-950 p-5 text-white">
              <p className="text-sm text-slate-300">Parsed resume skills</p>
              <p className="mt-3 text-3xl font-semibold">{resume?.skills.length ?? 0}</p>
            </div>
            <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
              <p className="text-sm text-slate-500">Saved jobs</p>
              <p className="mt-3 text-3xl font-semibold text-slate-900">{savedJobs.length}</p>
            </div>
            <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
              <p className="text-sm text-slate-500">Saved searches</p>
              <p className="mt-3 text-3xl font-semibold text-slate-900">{savedSearches.length}</p>
            </div>
          </div>
        </div>

        <div className="glass-panel rounded-[2rem] p-6">
          <div className="flex items-center gap-3">
            <div className="rounded-2xl bg-amber-100 p-3 text-amber-700">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <p className="font-semibold text-slate-900">Resume profile snapshot</p>
              <p className="text-sm text-slate-500">Rules-based extraction from your latest resume upload</p>
            </div>
          </div>

          {resume ? (
            <div className="mt-5 space-y-4">
              <div>
                <p className="text-sm text-slate-500">Detected identity</p>
                <p className="font-semibold text-slate-900">{resume.name ?? user.name}</p>
                <p className="text-sm text-slate-500">{resume.email ?? user.email}</p>
              </div>
              <div>
                <p className="text-sm text-slate-500">Top skills</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {resume.skills.slice(0, 8).map((skill) => (
                    <span key={skill} className="rounded-full bg-slate-100 px-3 py-1 text-sm text-slate-700">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <p className="mt-5 text-sm leading-7 text-slate-600">
              No resume uploaded yet. You can still search jobs, but ranking will get much stronger once a resume is
              available.
            </p>
          )}
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <form onSubmit={handleSearch} className="glass-panel rounded-[2rem] p-6">
          <div className="flex items-center gap-3">
            <div className="rounded-2xl bg-teal-100 p-3 text-teal-700">
              <Search className="h-5 w-5" />
            </div>
            <div>
              <p className="font-semibold text-slate-900">Job search</p>
              <p className="text-sm text-slate-500">Search with resume-aware ranking and structured filters</p>
            </div>
          </div>

          <div className="mt-5 grid gap-4 md:grid-cols-2">
            <Input name="desiredTitle" placeholder="Desired job title" required />
            <Input name="country" placeholder="Country" required />
            <Input name="state" placeholder="State / region" />
            <Input name="city" placeholder="City" />
            <Select name="remoteMode" defaultValue="">
              <option value="">Remote preference</option>
              <option value="REMOTE">Remote</option>
              <option value="HYBRID">Hybrid</option>
              <option value="ONSITE">Onsite</option>
              <option value="FLEXIBLE">Flexible</option>
            </Select>
            <Select name="employmentType" defaultValue="">
              <option value="">Employment type</option>
              <option value="FULL_TIME">Full-time</option>
              <option value="PART_TIME">Part-time</option>
              <option value="CONTRACT">Contract</option>
              <option value="INTERNSHIP">Internship</option>
            </Select>
            <Input name="salaryMin" type="number" placeholder="Salary min" />
            <Input name="salaryMax" type="number" placeholder="Salary max" />
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <Button type="submit">Search jobs</Button>
            <Button type="button" variant="secondary" onClick={saveSearch} disabled={results.length === 0}>
              Save search + alerts
            </Button>
          </div>

          {status && <p className="mt-4 text-sm text-slate-600">{status}</p>}
        </form>

        <form onSubmit={handleResumeUpload} className="glass-panel rounded-[2rem] p-6">
          <div className="flex items-center gap-3">
            <div className="rounded-2xl bg-slate-100 p-3 text-slate-700">
              <BriefcaseBusiness className="h-5 w-5" />
            </div>
            <div>
              <p className="font-semibold text-slate-900">Resume upload</p>
              <p className="text-sm text-slate-500">PDF and DOCX are supported with secure local dev storage</p>
            </div>
          </div>

          <div className="mt-5 space-y-4">
            <input
              name="resume"
              type="file"
              accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
              className="block w-full rounded-2xl border border-dashed border-slate-300 bg-white px-4 py-6 text-sm text-slate-600"
              required
            />
            <Textarea
              readOnly
              value={
                resume
                  ? `Preferred roles: ${resume.preferredRoles.join(", ") || "Not detected"}\nExperience keywords: ${
                      resume.experienceKeywords.join(", ") || "Not detected"
                    }`
                  : "Upload a resume to extract skills, experience keywords, education keywords, and likely preferred roles."
              }
              rows={7}
            />
          </div>

          <Button type="submit" className="mt-5">
            Upload and parse
          </Button>
        </form>
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <div className="glass-panel rounded-[2rem] p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-semibold text-slate-900">Ranked results</p>
              <p className="text-sm text-slate-500">Switch views and sort based on what matters most right now</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button variant={view === "cards" ? "primary" : "secondary"} onClick={() => setView("cards")}>
                <LayoutGrid className="mr-2 h-4 w-4" />
                Cards
              </Button>
              <Button variant={view === "table" ? "primary" : "secondary"} onClick={() => setView("table")}>
                <List className="mr-2 h-4 w-4" />
                Table
              </Button>
              <Select value={sortBy} onChange={(event) => setSortBy(event.target.value as typeof sortBy)}>
                <option value="best-match">Best match</option>
                <option value="newest">Newest</option>
                <option value="salary">Salary</option>
              </Select>
            </div>
          </div>

          {sortedResults.length === 0 ? (
            <div className="mt-5 rounded-[1.5rem] border border-dashed border-slate-300 bg-white/70 p-8 text-center text-sm leading-7 text-slate-500">
              No search results yet. Run a search to see ranked matches and resume-fit explanations.
            </div>
          ) : view === "cards" ? (
            <div className="mt-5 grid gap-4">
              {sortedResults.map((job) => (
                <article
                  key={`${job.source}-${job.externalJobId}`}
                  className={`rounded-[1.6rem] border bg-white p-5 shadow-sm transition ${
                    selectedJob?.externalJobId === job.externalJobId
                      ? "border-teal-400 ring-4 ring-teal-100"
                      : "border-slate-200"
                  }`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <p className="text-xl font-semibold text-slate-900">{job.title}</p>
                      <p className="mt-1 text-sm text-slate-500">
                        {job.company} · {job.location}
                      </p>
                    </div>
                    <span className="rounded-full bg-teal-100 px-3 py-1 text-sm font-semibold text-teal-800">
                      {job.matchScore}/100
                    </span>
                  </div>
                  <p className="mt-4 text-sm leading-7 text-slate-600">{job.descriptionSnippet}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {job.matchReasons.map((reason) => (
                      <span key={reason} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600">
                        {reason}
                      </span>
                    ))}
                  </div>
                  <div className="mt-5 flex flex-wrap gap-3">
                    <Button variant="secondary" type="button" onClick={() => setSelectedJob(job)}>
                      Inspect fit
                    </Button>
                    <Button type="button" onClick={() => saveJob(job)}>
                      Save job
                    </Button>
                    <a
                      href={job.applyUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center rounded-2xl px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-100"
                    >
                      Open apply link
                    </a>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="mt-5 overflow-hidden rounded-[1.5rem] border border-slate-200">
              <table className="min-w-full bg-white text-left text-sm">
                <thead className="bg-slate-50 text-slate-500">
                  <tr>
                    <th className="px-4 py-3">Role</th>
                    <th className="px-4 py-3">Company</th>
                    <th className="px-4 py-3">Score</th>
                    <th className="px-4 py-3">Salary</th>
                    <th className="px-4 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedResults.map((job) => (
                    <tr key={job.externalJobId} className="border-t border-slate-100">
                      <td className="px-4 py-3">
                        <p className="font-medium text-slate-900">{job.title}</p>
                        <p className="text-xs text-slate-500">{job.location}</p>
                      </td>
                      <td className="px-4 py-3">{job.company}</td>
                      <td className="px-4 py-3">{job.matchScore}</td>
                      <td className="px-4 py-3">{formatCurrencyRange(job.salaryMin, job.salaryMax)}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2">
                          <Button variant="secondary" type="button" onClick={() => setSelectedJob(job)}>
                            View
                          </Button>
                          <Button type="button" onClick={() => saveJob(job)}>
                            Save
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="glass-panel rounded-[2rem] p-6">
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-amber-100 p-3 text-amber-700">
                <Sparkles className="h-5 w-5" />
              </div>
              <div>
                <p className="font-semibold text-slate-900">Resume improvement helper</p>
                <p className="text-sm text-slate-500">Rules-based recommendations for the selected job</p>
              </div>
            </div>
            <p className="mt-5 text-sm leading-7 text-slate-600">{resumeSuggestions.summary}</p>
            <div className="mt-5">
              <p className="text-sm font-semibold text-slate-800">Missing keywords</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {resumeSuggestions.missingSkills.length ? (
                  resumeSuggestions.missingSkills.map((item) => (
                    <span key={item} className="rounded-full bg-amber-100 px-3 py-1 text-sm text-amber-900">
                      {item}
                    </span>
                  ))
                ) : (
                  <span className="text-sm text-slate-500">No missing keywords surfaced yet.</span>
                )}
              </div>
            </div>
            <div className="mt-5">
              <p className="text-sm font-semibold text-slate-800">Wording upgrades</p>
              <ul className="mt-3 space-y-2 text-sm leading-7 text-slate-600">
                {resumeSuggestions.wording.map((item) => (
                  <li key={item}>- {item}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="glass-panel rounded-[2rem] p-6">
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-slate-100 p-3 text-slate-700">
                <Bookmark className="h-5 w-5" />
              </div>
              <div>
                <p className="font-semibold text-slate-900">Saved jobs</p>
                <p className="text-sm text-slate-500">Quick shortlist of roles you want to revisit</p>
              </div>
            </div>
            <div className="mt-5 space-y-4">
              {savedJobs.length ? (
                savedJobs.map((job) => (
                  <div key={job.id} className="rounded-3xl bg-white p-4 ring-1 ring-slate-200">
                    <p className="font-semibold text-slate-900">{job.title}</p>
                    <p className="text-sm text-slate-500">
                      {job.company} · {job.location}
                    </p>
                    <div className="mt-3 flex gap-3">
                      <a href={job.applyUrl} target="_blank" rel="noreferrer" className="text-sm font-medium text-teal-700">
                        Apply
                      </a>
                      <button
                        type="button"
                        onClick={() => removeSavedJob(job.id)}
                        className="text-sm font-medium text-red-700"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-slate-500">No saved jobs yet.</p>
              )}
            </div>
          </div>

          <div className="glass-panel rounded-[2rem] p-6">
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-slate-100 p-3 text-slate-700">
                <Clock3 className="h-5 w-5" />
              </div>
              <div>
                <p className="font-semibold text-slate-900">Saved searches and history</p>
                <p className="text-sm text-slate-500">Track alert-enabled searches and recent query activity</p>
              </div>
            </div>
            <div className="mt-5 space-y-4">
              <div>
                <p className="text-sm font-semibold text-slate-800">Saved searches</p>
                <div className="mt-3 space-y-2">
                  {savedSearches.length ? (
                    savedSearches.map((search) => (
                      <div key={search.id} className="rounded-2xl bg-white p-3 ring-1 ring-slate-200">
                        <p className="font-medium text-slate-900">{search.name}</p>
                        <p className="text-xs text-slate-500">
                          Alerts {search.alertsEnabled ? "enabled" : "disabled"}
                        </p>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-slate-500">No saved searches yet.</p>
                  )}
                </div>
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-800">Recent history</p>
                <div className="mt-3 space-y-2">
                  {initialHistory.length ? (
                    initialHistory.map((entry) => (
                      <div key={entry.id} className="rounded-2xl bg-white p-3 ring-1 ring-slate-200">
                        <p className="font-medium text-slate-900">
                          {entry.desiredTitle} · {entry.country}
                        </p>
                        <p className="text-xs text-slate-500">
                          {entry.resultsCount} results · {new Date(entry.createdAt).toLocaleString()}
                        </p>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-slate-500">No search history yet.</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
