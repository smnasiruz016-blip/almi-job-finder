import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth";
import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { getLatestParsedResume } from "@/server/services/resume-service";

export default async function DashboardPage() {
  const user = await requireUser();
  const [resume, savedJobs, savedSearches, history] = await Promise.all([
    getLatestParsedResume(user.id),
    prisma.savedJob.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: 5
    }),
    prisma.savedSearch.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: 5
    }),
    prisma.jobSearch.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: 5
    })
  ]);

  return (
    <DashboardShell
      user={user}
      resume={resume}
      initialSavedJobs={savedJobs}
      initialSavedSearches={savedSearches}
      initialHistory={history.map((entry) => ({
        id: entry.id,
        createdAt: entry.createdAt.toISOString(),
        resultsCount: Array.isArray(entry.latestResults) ? entry.latestResults.length : 0,
        desiredTitle: entry.desiredTitle,
        country: entry.country
      }))}
    />
  );
}
