import type { ParsedResume, RankedJob } from "@/types";

export function buildResumeSuggestions(resume: ParsedResume | null, selectedJob?: RankedJob | null) {
  if (!resume || !selectedJob) {
    return {
      strongerSummary:
        "Add a top-of-resume summary that targets your preferred role, years of experience, and the outcomes you drive.",
      missingSkills: [],
      wordingUpgrades: [
        "Replace passive bullets with action + impact phrasing.",
        "Include measurable outcomes where possible."
      ]
    };
  }

  return {
    strongerSummary: `Tailor your summary toward ${selectedJob.title} roles and call out ${selectedJob.company}'s likely needs: ${selectedJob.keywords
      .slice(0, 3)
      .join(", ")}.`,
    missingSkills: selectedJob.missingKeywords,
    wordingUpgrades: [
      "Turn generic collaboration bullets into concrete ownership statements.",
      "Mirror the job language for tools and domain keywords where accurate.",
      "Move your most relevant project or role higher on the page."
    ]
  };
}
