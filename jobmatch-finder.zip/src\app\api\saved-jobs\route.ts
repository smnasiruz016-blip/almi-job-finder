import { getRequiredUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { jsonError } from "@/lib/http";

export async function POST(request: Request) {
  let user;

  try {
    user = await getRequiredUser();
  } catch {
    return jsonError("Unauthorized.", 401);
  }

  const body = await request.json();

  if (!body.externalJobId || !body.source) {
    return jsonError("Job payload is incomplete.");
  }

  const savedJob = await prisma.savedJob.upsert({
    where: {
      userId_externalJobId_source: {
        userId: user.id,
        externalJobId: body.externalJobId,
        source: body.source
      }
    },
    update: {
      payload: body
    },
    create: {
      userId: user.id,
      externalJobId: body.externalJobId,
      source: body.source,
      title: body.title,
      company: body.company,
      location: body.location,
      applyUrl: body.applyUrl,
      payload: body
    }
  });

  return Response.json({ savedJob });
}

export async function DELETE(request: Request) {
  let user;

  try {
    user = await getRequiredUser();
  } catch {
    return jsonError("Unauthorized.", 401);
  }

  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");

  if (!id) {
    return jsonError("Saved job id is required.");
  }

  await prisma.savedJob.deleteMany({
    where: {
      id,
      userId: user.id
    }
  });

  return Response.json({ ok: true });
}
