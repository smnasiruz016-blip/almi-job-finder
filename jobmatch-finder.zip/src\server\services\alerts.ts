import { prisma } from "@/lib/prisma";
import { getEmailProvider } from "@/server/services/email";
import { runJobSearch } from "@/server/services/job-search";
import { getLatestParsedResume } from "@/server/services/resume-service";
import type { JobSearchInput } from "@/types";

export async function processDailyAlerts() {
  const searches = await prisma.savedSearch.findMany({
    where: {
      alertsEnabled: true
    },
    include: {
      user: true
    }
  });

  const email = getEmailProvider();
  let processed = 0;

  for (const search of searches) {
    const resume = await getLatestParsedResume(search.userId);
    const { results } = await runJobSearch(search.userId, search.querySnapshot as JobSearchInput, resume);
    const topMatches = results.slice(0, 3);

    await email.sendEmail(
      search.user.email,
      `JobMatch Finder alert: ${search.name}`,
      `<h1>${search.name}</h1><p>${topMatches
        .map((job) => `${job.title} at ${job.company} (${job.matchScore})`)
        .join("<br/>")}</p>`
    );

    await prisma.savedSearch.update({
      where: { id: search.id },
      data: { lastAlertedAt: new Date() }
    });

    processed += 1;
  }

  return {
    processed
  };
}
