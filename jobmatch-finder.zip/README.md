# JobMatch Finder

JobMatch Finder is a production-minded MVP job search web app built with Next.js, TypeScript, Tailwind, Prisma, and PostgreSQL. Users can create an account, upload a resume, search approved job sources through adapters, rank jobs by resume fit, save jobs and searches, and enable daily alert processing through a cron-friendly endpoint.

## Implementation Summary

### Architecture
- UI: Next.js App Router pages and reusable dashboard/auth components in `src/app` and `src/components`
- API: Route handlers in `src/app/api`
- Shared utilities: auth, Prisma, validation, logging, rate limiting in `src/lib`
- Services: resume parsing, ranking, alerts, admin stats, job orchestration in `src/server/services`
- Provider adapters: extensible interface and mock providers in `src/server/adapters`
- Storage: local file storage abstraction in `src/server/storage`
- Persistence: PostgreSQL schema and seed in `prisma`

### Folder Structure
- `src/app`: routes, layouts, pages, API handlers
- `src/components`: UI primitives, forms, dashboard modules
- `src/lib`: auth, validation, utilities, logging, Prisma, rate limiting
- `src/server/adapters`: mock providers and official API placeholders
- `src/server/parsers`: resume text extraction and rules-based parsing
- `src/server/services`: ranking engine, job search orchestration, resume helper, alerts, admin
- `src/server/storage`: storage abstraction for uploaded files
- `prisma`: schema and seed script
- `tests`: parser, ranking, and API route tests

### Database Schema
- `User`: credentials, role, timestamps
- `Session`: cookie-backed session storage
- `Resume`: original file metadata, extracted text, parsed profile arrays
- `JobSearch`: persisted search parameters plus latest results snapshot
- `SearchHistory`: search audit trail with result counts
- `SavedJob`: saved job shortlist entries
- `SavedSearch`: alert-enabled saved queries
- `JobResultCache`: normalized provider result snapshots for dedupe and traceability

## Features Included

- Email/password sign up, login, logout, protected dashboard, basic admin gate
- Resume upload with PDF/DOCX support hooks and rules-based resume parsing
- Search form with title, country, state, city, remote mode, employment type, salary filters
- Adapter-based job aggregation with mock providers and placeholders for approved official APIs
- Resume-aware ranking and match explanations
- Card and table result views with sorting
- Save job, remove saved job, save searches with alert preferences, search history
- Resume improvement helper with missing keyword and wording suggestions
- Admin stats page
- Rate limiting on search endpoint
- Logging, input validation, file type and size checks, and local storage abstraction

## Local Setup

### Prerequisites
- Node.js 20+ or the bundled Codex workspace runtime
- PostgreSQL running locally
- A package manager such as `pnpm` or `npm`

### Steps
1. Copy `.env.example` to `.env` and update `DATABASE_URL`.
2. Install dependencies:

```bash
pnpm install
```

3. Generate Prisma client and push the schema:

```bash
pnpm db:generate
pnpm db:push
```

4. Seed demo data:

```bash
pnpm db:seed
```

5. Start the app:

```bash
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000).

### Demo Accounts
- Admin: `admin@jobmatchfinder.dev` / `Password123!`
- User: `demo@jobmatchfinder.dev` / `Password123!`

## How Search Providers Work

This MVP intentionally avoids unauthorized scraping. The provider layer uses a `JobSourceAdapter` interface:

```ts
export interface JobSourceAdapter {
  source: string;
  isEnabled(): boolean;
  searchJobs(input: JobSearchInput): Promise<NormalizedJob[]>;
}
```

Current implementation:
- `MockGreenhouse`
- `MockLever`
- `MockWorkable`

Placeholders are included for official or approved API integrations such as Greenhouse and Lever. To add a new provider:

1. Create a new adapter in `src/server/adapters`.
2. Implement `isEnabled()` based on environment variables or feature flags.
3. Normalize provider responses into `NormalizedJob`.
4. Register the adapter in `src/server/adapters/provider-registry.ts`.

## Alerts

Saved searches can enable alerts. The app exposes a cron-friendly endpoint:

- `POST /api/cron/daily-alerts`
- Include header `x-cron-secret: <CRON_SECRET>` when `CRON_SECRET` is set

For MVP purposes, the email provider is a dev stub that logs outgoing alert content. Replace `getEmailProvider()` with a real provider in `src/server/services/email.ts` for production use.

## Tests

Included tests cover:
- Resume parsing utility
- Ranking logic
- Job search API route validation

Run:

```bash
pnpm test
```

## Security and Production Notes

- Passwords are hashed with `bcryptjs`
- Sessions are stored server-side and sent in an HTTP-only cookie
- Search API uses in-memory rate limiting suitable for MVP and single-instance deployment
- Uploads are restricted by MIME type and size
- File storage is abstracted for local dev and future cloud migration
- Validation uses `zod`
- Logging is centralized via `src/lib/logger.ts`

## What Is Complete

- End-to-end mock flow for auth, resume upload, search, ranking, save job, save search, and admin stats
- Extensible source adapter pattern
- PostgreSQL Prisma schema and seed data
- Test coverage for the requested areas
- `.env.example` and setup documentation

## Placeholder Areas

- Official job provider APIs are stubs pending approved credentials and provider-specific contracts
- Email delivery uses a dev logging provider
- File storage is local-only in dev, with cloud placeholders ready
- Resume parsing is rules-based and intentionally lightweight for MVP
- In-memory rate limiting should be upgraded for distributed production deployments

## V2 Roadmap

- Replace rules-based resume parsing with configurable extraction pipelines and embeddings-assisted matching
- Add real email delivery and a durable job queue
- Support richer saved search editing and user notification controls
- Add organization workspaces and recruiter-facing features
- Introduce provider-specific health checks and ingestion observability
- Improve result deduplication and resume version comparison
