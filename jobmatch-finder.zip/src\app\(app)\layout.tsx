import Link from "next/link";
import { BarChart3, Shield, UserRound } from "lucide-react";
import { requireUser } from "@/lib/auth";

export default async function AppLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  const user = await requireUser();

  return (
    <div className="min-h-screen py-6">
      <div className="page-shell">
        <header className="glass-panel mb-6 flex flex-wrap items-center justify-between rounded-[2rem] px-5 py-4">
          <div>
            <Link href="/dashboard" className="font-[family-name:var(--font-display)] text-xl font-bold text-slate-950">
              JobMatch Finder
            </Link>
            <p className="text-sm text-slate-500">Search smarter with resume-aware ranking</p>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/dashboard" className="inline-flex items-center gap-2 rounded-2xl px-4 py-2 text-sm text-slate-600 hover:bg-slate-100">
              <BarChart3 className="h-4 w-4" />
              Dashboard
            </Link>
            {user.role === "ADMIN" && (
              <Link href="/admin" className="inline-flex items-center gap-2 rounded-2xl px-4 py-2 text-sm text-slate-600 hover:bg-slate-100">
                <Shield className="h-4 w-4" />
                Admin
              </Link>
            )}
            <div className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-4 py-2 text-sm text-slate-700">
              <UserRound className="h-4 w-4" />
              {user.email}
            </div>
          </div>
        </header>
        {children}
      </div>
    </div>
  );
}
