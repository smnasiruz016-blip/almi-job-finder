import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/forms/auth-form";
import { getCurrentUser } from "@/lib/auth";

export default async function LoginPage() {
  const user = await getCurrentUser();

  if (user) {
    redirect("/dashboard");
  }

  return (
    <main className="page-shell py-16">
      <AuthForm mode="login" />
      <p className="mt-6 text-center text-sm text-slate-500">
        Need an account?{" "}
        <Link href="/signup" className="font-semibold text-teal-700">
          Sign up
        </Link>
      </p>
    </main>
  );
}
