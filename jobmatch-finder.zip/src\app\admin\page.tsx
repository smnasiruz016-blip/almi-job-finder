import { requireAdmin } from "@/lib/auth";
import { getAdminStats } from "@/server/services/admin";

export default async function AdminPage() {
  await requireAdmin();
  const stats = await getAdminStats();

  return (
    <main className="grid gap-6 md:grid-cols-2 xl:grid-cols-5">
      {Object.entries(stats).map(([label, value]) => (
        <section key={label} className="glass-panel rounded-[2rem] p-6">
          <p className="text-sm uppercase tracking-[0.18em] text-slate-400">{label}</p>
          <p className="mt-4 text-4xl font-bold text-slate-950">{value}</p>
        </section>
      ))}
    </main>
  );
}
