import { prisma } from "@/lib/prisma";

export async function getAdminStats() {
  const [users, resumes, searches, savedJobs, savedSearches] = await Promise.all([
    prisma.user.count(),
    prisma.resume.count(),
    prisma.jobSearch.count(),
    prisma.savedJob.count(),
    prisma.savedSearch.count()
  ]);

  return {
    users,
    resumes,
    searches,
    savedJobs,
    savedSearches
  };
}
