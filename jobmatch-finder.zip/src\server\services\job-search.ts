import { prisma } from "@/lib/prisma";
import { getJobAdapters } from "@/server/adapters/provider-registry";
import { rankJobs } from "@/server/services/ranking";
import type { JobSearchInput, ParsedResume } from "@/types";

export async function runJobSearch(userId: string, input: JobSearchInput, resume?: ParsedResume | null) {
  const adapters = getJobAdapters();
  const results = (await Promise.all(adapters.map((adapter) => adapter.searchJobs(input)))).flat();
  const ranked = rankJobs(results, input, resume);

  const search = await prisma.jobSearch.create({
    data: {
      userId,
      desiredTitle: input.desiredTitle,
      country: input.country,
      state: input.state,
      city: input.city,
      remoteMode: input.remoteMode,
      employmentType: input.employmentType,
      salaryMin: input.salaryMin,
      salaryMax: input.salaryMax,
      latestResults: ranked
    }
  });

  await prisma.searchHistory.create({
    data: {
      userId,
      searchId: search.id,
      snapshot: input,
      resultsCount: ranked.length
    }
  });

  for (const job of ranked) {
    await prisma.jobResultCache.upsert({
      where: {
        externalJobId_source: {
          externalJobId: job.externalJobId,
          source: job.source
        }
      },
      update: {
        payload: job,
        title: job.title,
        company: job.company,
        location: job.location,
        postedDate: job.postedDate ? new Date(job.postedDate) : null
      },
      create: {
        externalJobId: job.externalJobId,
        source: job.source,
        title: job.title,
        company: job.company,
        location: job.location,
        postedDate: job.postedDate ? new Date(job.postedDate) : null,
        payload: job
      }
    });
  }

  return {
    searchId: search.id,
    results: ranked
  };
}
