import { getRequiredUser } from "@/lib/auth";
import { getClientIdentifier, jsonError } from "@/lib/http";
import { log } from "@/lib/logger";
import { checkRateLimit } from "@/lib/rate-limit";
import { jobSearchSchema } from "@/lib/validation";
import { runJobSearch } from "@/server/services/job-search";
import { getLatestParsedResume } from "@/server/services/resume-service";

export async function POST(request: Request) {
  let user;

  try {
    user = await getRequiredUser();
  } catch {
    return jsonError("Unauthorized.", 401);
  }

  const limiter = checkRateLimit(`search:${user.id}:${getClientIdentifier(request)}`, 15, 60_000);

  if (!limiter.success) {
    return jsonError("Too many searches. Please wait a minute and try again.", 429);
  }

  const body = await request.json();
  const parsed = jobSearchSchema.safeParse(body);

  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid job search payload.");
  }

  try {
    const resume = await getLatestParsedResume(user.id);
    const result = await runJobSearch(user.id, parsed.data, resume);
    return Response.json(result);
  } catch (error) {
    log("error", "Job search failed", {
      userId: user.id,
      error: error instanceof Error ? error.message : "Unknown"
    });
    return jsonError("Search failed. Please try again.");
  }
}
