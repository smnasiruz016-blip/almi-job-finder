import type { JobSearchInput, NormalizedJob } from "@/types";

export interface JobSourceAdapter {
  source: string;
  isEnabled(): boolean;
  searchJobs(input: JobSearchInput): Promise<NormalizedJob[]>;
}
