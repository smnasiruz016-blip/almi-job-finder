import { beforeEach, describe, expect, it, vi } from "vitest";

const getRequiredUser = vi.fn();
const getLatestParsedResume = vi.fn();
const runJobSearch = vi.fn();

vi.mock("@/lib/auth", () => ({
  getRequiredUser
}));

vi.mock("@/server/services/resume-service", () => ({
  getLatestParsedResume
}));

vi.mock("@/server/services/job-search", () => ({
  runJobSearch
}));

describe("POST /api/jobs/search", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns validation errors for invalid search payloads", async () => {
    getRequiredUser.mockResolvedValue({
      id: "user_1",
      email: "demo@example.com",
      name: "Demo User",
      role: "USER"
    });

    const { POST } = await import("@/app/api/jobs/search/route");
    const response = await POST(
      new Request("http://localhost/api/jobs/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          desiredTitle: "",
          country: ""
        })
      })
    );

    expect(response.status).toBe(400);
    expect(await response.json()).toEqual(
      expect.objectContaining({
        error: expect.any(String)
      })
    );
    expect(runJobSearch).not.toHaveBeenCalled();
  });
});
