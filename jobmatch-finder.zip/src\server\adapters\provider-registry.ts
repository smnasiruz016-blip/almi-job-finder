import type { JobSourceAdapter } from "@/server/adapters/types";
import { mockAdapters } from "@/server/adapters/mock-jobs";

class GreenhouseApiAdapter implements JobSourceAdapter {
  source = "GreenhouseOfficialApi";

  isEnabled() {
    return Boolean(process.env.GREENHOUSE_API_BASE_URL);
  }

  async searchJobs(_input: import("@/types").JobSearchInput) {
    return [];
  }
}

class LeverApiAdapter implements JobSourceAdapter {
  source = "LeverOfficialApi";

  isEnabled() {
    return Boolean(process.env.LEVER_API_BASE_URL);
  }

  async searchJobs(_input: import("@/types").JobSearchInput) {
    return [];
  }
}

export function getJobAdapters() {
  return [...mockAdapters, new GreenhouseApiAdapter(), new LeverApiAdapter()].filter((adapter) => adapter.isEnabled());
}
