import { rankJobs } from "@/server/services/ranking";
import type { JobSearchInput, ParsedResume } from "@/types";

describe("rankJobs", () => {
  it("prioritizes jobs that fit title, skills, and remote preference", () => {
    const search: JobSearchInput = {
      desiredTitle: "Frontend Engineer",
      country: "United States",
      remoteMode: "REMOTE"
    };

    const resume: ParsedResume = {
      name: "Jordan Rivera",
      email: "jordan@example.com",
      phone: "555",
      skills: ["TypeScript", "Next.js", "Prisma"],
      experienceKeywords: ["dashboards", "performance"],
      educationKeywords: ["Computer Science"],
      preferredRoles: ["Frontend Engineer"],
      rawText: "resume"
    };

    const ranked = rankJobs(
      [
        {
          externalJobId: "best",
          source: "mock",
          title: "Frontend Engineer",
          company: "Northstar",
          location: "Remote, United States",
          salaryMin: 100000,
          salaryMax: 120000,
          jobType: "FULL_TIME",
          remoteStatus: "REMOTE",
          descriptionSnippet: "Build performance-focused dashboards in TypeScript and Next.js.",
          applyUrl: "https://example.com",
          keywords: ["typescript", "next.js", "performance"]
        },
        {
          externalJobId: "weaker",
          source: "mock",
          title: "Product Designer",
          company: "Atlas",
          location: "Austin, Texas, United States",
          salaryMin: 100000,
          salaryMax: 120000,
          jobType: "FULL_TIME",
          remoteStatus: "HYBRID",
          descriptionSnippet: "Lead user research and Figma delivery.",
          applyUrl: "https://example.com",
          keywords: ["figma", "user research"]
        }
      ],
      search,
      resume
    );

    expect(ranked[0].externalJobId).toBe("best");
    expect(ranked[0].matchScore).toBeGreaterThan(ranked[1].matchScore);
    expect(ranked[0].matchReasons.join(" ")).toContain("Title aligns");
  });
});
