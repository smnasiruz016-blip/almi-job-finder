import { getRequiredUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { jsonError } from "@/lib/http";
import { saveSearchSchema } from "@/lib/validation";

export async function POST(request: Request) {
  let user;

  try {
    user = await getRequiredUser();
  } catch {
    return jsonError("Unauthorized.", 401);
  }

  const body = await request.json();
  const parsed = saveSearchSchema.safeParse(body);

  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid saved search payload.");
  }

  const savedSearch = await prisma.savedSearch.create({
    data: {
      userId: user.id,
      name: parsed.data.name,
      querySnapshot: parsed.data.querySnapshot,
      alertsEnabled: parsed.data.alertsEnabled,
      alertFrequency: parsed.data.alertFrequency
    }
  });

  return Response.json({ savedSearch });
}
