import type { EmploymentType, RemoteMode, UserRole } from "@prisma/client";

export type SessionUser = {
  id: string;
  name: string;
  email: string;
  role: UserRole;
};

export type ParsedResume = {
  name?: string;
  email?: string;
  phone?: string;
  skills: string[];
  experienceKeywords: string[];
  educationKeywords: string[];
  preferredRoles: string[];
  rawText: string;
};

export type JobSearchInput = {
  desiredTitle: string;
  country: string;
  state?: string;
  city?: string;
  remoteMode?: RemoteMode;
  employmentType?: EmploymentType;
  salaryMin?: number;
  salaryMax?: number;
};

export type NormalizedJob = {
  externalJobId: string;
  source: string;
  title: string;
  company: string;
  location: string;
  salary?: string;
  salaryMin?: number;
  salaryMax?: number;
  jobType?: string;
  remoteStatus?: string;
  descriptionSnippet: string;
  applyUrl: string;
  postedDate?: string;
  keywords: string[];
};

export type RankedJob = NormalizedJob & {
  matchScore: number;
  matchReasons: string[];
  missingKeywords: string[];
};
