import Link from "next/link";
import { ArrowRight, CheckCircle2, SearchCode, ShieldCheck, Sparkles, Upload } from "lucide-react";
import { getCurrentUser } from "@/lib/auth";

const highlights = [
  {
    icon: Upload,
    title: "Resume-aware matching",
    description: "Parse PDF or DOCX resumes, infer skills, and rank openings against your actual profile."
  },
  {
    icon: SearchCode,
    title: "Approved source adapters",
    description: "Start with mock providers now and add official APIs later through a clean adapter contract."
  },
  {
    icon: Sparkles,
    title: "Actionable fit insights",
    description: "See why a role scored well and which keywords your resume is still missing."
  },
  {
    icon: ShieldCheck,
    title: "Production-minded foundation",
    description: "Validation, rate limiting, logging, storage abstraction, and Prisma-backed persistence are built in."
  }
];

export default async function HomePage() {
  const user = await getCurrentUser();

  return (
    <main className="pb-16">
      <section className="page-shell pt-8 md:pt-12">
        <nav className="glass-panel flex items-center justify-between rounded-full px-5 py-3">
          <div>
            <p className="font-[family-name:var(--font-display)] text-lg font-semibold">JobMatch Finder</p>
            <p className="text-sm text-slate-500">Resume-first job discovery for practical teams</p>
          </div>
          <div className="flex items-center gap-3 text-sm font-medium">
            {user ? (
              <Link
                href="/dashboard"
                className="rounded-full bg-teal-700 px-4 py-2 text-white transition hover:bg-teal-800"
              >
                Open dashboard
              </Link>
            ) : (
              <>
                <Link href="/login" className="rounded-full px-4 py-2 text-slate-600 transition hover:bg-slate-100">
                  Log in
                </Link>
                <Link
                  href="/signup"
                  className="rounded-full bg-teal-700 px-4 py-2 text-white transition hover:bg-teal-800"
                >
                  Start free
                </Link>
              </>
            )}
          </div>
        </nav>

        <div className="grid gap-8 pb-16 pt-10 md:grid-cols-[1.2fr_0.8fr] md:items-center md:pt-16">
          <div className="space-y-6">
            <span className="eyebrow">Production-ready MVP</span>
            <div className="space-y-4">
              <h1 className="section-title max-w-3xl font-[family-name:var(--font-display)]">
                Find jobs that actually fit your resume, not just your keyword search.
              </h1>
              <p className="max-w-2xl text-lg leading-8 text-slate-600">
                Upload a resume, set your role and location preferences, and get ranked opportunities with explainable
                match scores, saveable searches, and practical resume improvement suggestions.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link
                href={user ? "/dashboard" : "/signup"}
                className="inline-flex items-center gap-2 rounded-full bg-slate-950 px-5 py-3 font-medium text-white transition hover:bg-slate-800"
              >
                {user ? "Go to dashboard" : "Create account"}
                <ArrowRight className="h-4 w-4" />
              </Link>
              <a
                href="#features"
                className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-3 font-medium text-slate-700 transition hover:border-slate-300 hover:bg-slate-50"
              >
                Explore features
              </a>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              {["Auth + dashboard", "Resume parsing", "Ranked job search"].map((item) => (
                <div key={item} className="rounded-2xl border border-slate-200 bg-white/80 p-4">
                  <CheckCircle2 className="mb-2 h-5 w-5 text-teal-700" />
                  <p className="text-sm font-semibold text-slate-800">{item}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-panel rounded-[2rem] p-6">
            <div className="rounded-[1.5rem] bg-slate-950 p-6 text-white">
              <div className="flex items-center justify-between">
                <p className="font-semibold">Sample match preview</p>
                <span className="rounded-full bg-teal-500/20 px-3 py-1 text-sm text-teal-200">92 / 100</span>
              </div>
              <div className="mt-6 space-y-5">
                <div>
                  <p className="text-xl font-semibold">Senior Product Designer</p>
                  <p className="text-sm text-slate-300">Atlas Commerce · Austin, Texas · Hybrid</p>
                </div>
                <div className="space-y-3 rounded-3xl bg-white/8 p-4 text-sm text-slate-200">
                  <p className="font-medium text-white">Why it matched</p>
                  <ul className="space-y-2">
                    <li>Strong title overlap with your preferred role: Product Designer</li>
                    <li>Matched core resume skills: Figma, design systems, user research</li>
                    <li>Experience signals aligned with collaboration and experimentation keywords</li>
                    <li>Location and hybrid preference both aligned</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="page-shell">
        <div className="grid gap-4 md:grid-cols-2">
          {highlights.map(({ icon: Icon, title, description }) => (
            <article key={title} className="glass-panel rounded-[2rem] p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-700 text-white">
                <Icon className="h-5 w-5" />
              </div>
              <h2 className="mt-5 text-xl font-semibold text-slate-900">{title}</h2>
              <p className="mt-3 leading-7 text-slate-600">{description}</p>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
