import type { Metadata } from "next";
import { Inter, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { AppToaster } from "@/components/ui/app-toaster";

const bodyFont = Inter({
  subsets: ["latin"],
  variable: "--font-sans"
});

const displayFont = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-display"
});

export const metadata: Metadata = {
  title: "JobMatch Finder",
  description: "Upload your resume, search approved job sources, and rank roles by fit."
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${bodyFont.variable} ${displayFont.variable}`}>
        {children}
        <AppToaster />
      </body>
    </html>
  );
}
