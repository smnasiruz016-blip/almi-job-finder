import { EmploymentType, RemoteMode } from "@prisma/client";
import { z } from "zod";

export const signUpSchema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email(),
  password: z
    .string()
    .min(8)
    .regex(/[A-Z]/, "Must include one uppercase letter")
    .regex(/[a-z]/, "Must include one lowercase letter")
    .regex(/[0-9]/, "Must include one number")
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});

export const jobSearchSchema = z.object({
  desiredTitle: z.string().min(2).max(120),
  country: z.string().min(2).max(120),
  state: z.string().max(120).optional().or(z.literal("")),
  city: z.string().max(120).optional().or(z.literal("")),
  remoteMode: z.preprocess((value) => (value === "" ? undefined : value), z.nativeEnum(RemoteMode).optional()),
  employmentType: z.preprocess(
    (value) => (value === "" ? undefined : value),
    z.nativeEnum(EmploymentType).optional()
  ),
  salaryMin: z.preprocess((value) => (value === "" ? undefined : value), z.coerce.number().int().min(0).optional()),
  salaryMax: z.preprocess((value) => (value === "" ? undefined : value), z.coerce.number().int().min(0).optional())
}).refine((data) => !data.salaryMin || !data.salaryMax || data.salaryMax >= data.salaryMin, {
  message: "Salary max must be greater than or equal to salary min.",
  path: ["salaryMax"]
});

export const saveSearchSchema = z.object({
  name: z.string().min(2).max(80),
  alertsEnabled: z.boolean().default(false),
  alertFrequency: z.enum(["DAILY", "WEEKLY"]).default("DAILY"),
  querySnapshot: z.record(z.any())
});
