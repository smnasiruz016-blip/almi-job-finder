import { getRequiredUser } from "@/lib/auth";
import { jsonError } from "@/lib/http";
import { handleResumeUpload } from "@/server/services/resume-service";

export async function POST(request: Request) {
  let user;

  try {
    user = await getRequiredUser();
  } catch {
    return jsonError("Unauthorized.", 401);
  }

  const formData = await request.formData();
  const file = formData.get("resume");

  if (!(file instanceof File)) {
    return jsonError("Resume file is required.");
  }

  try {
    const { resume, parsed } = await handleResumeUpload(user.id, file);
    return Response.json({
      resumeId: resume.id,
      parsed
    });
  } catch (error) {
    return jsonError(error instanceof Error ? error.message : "Unable to upload resume.");
  }
}
