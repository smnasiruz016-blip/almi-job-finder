import type { JobSearchInput, NormalizedJob, ParsedResume, RankedJob } from "@/types";
import { dedupe } from "@/lib/utils";

function normalize(text: string) {
  return text.toLowerCase();
}

export function rankJobs(
  jobs: NormalizedJob[],
  search: JobSearchInput,
  resume?: ParsedResume | null
): RankedJob[] {
  const desiredTitle = normalize(search.desiredTitle);
  const resumeSkills = resume?.skills.map(normalize) ?? [];
  const resumeExperience = resume?.experienceKeywords.map(normalize) ?? [];

  return jobs
    .map((job) => {
      let score = 35;
      const reasons: string[] = [];
      const missingKeywords: string[] = [];
      const title = normalize(job.title);
      const location = normalize(job.location);
      const jobKeywords = job.keywords.map(normalize);

      if (title.includes(desiredTitle)) {
        score += 20;
        reasons.push(`Title aligns with ${search.desiredTitle}`);
      }

      const skillMatches = resumeSkills.filter((skill) => jobKeywords.some((keyword) => keyword.includes(skill) || skill.includes(keyword)));
      if (skillMatches.length) {
        score += Math.min(24, skillMatches.length * 6);
        reasons.push(`Resume skills matched: ${skillMatches.slice(0, 4).join(", ")}`);
      }

      const experienceMatches = resumeExperience.filter((item) =>
        job.descriptionSnippet.toLowerCase().includes(item) || jobKeywords.some((keyword) => keyword.includes(item))
      );
      if (experienceMatches.length) {
        score += Math.min(18, experienceMatches.length * 4);
        reasons.push(`Experience keywords aligned: ${experienceMatches.slice(0, 3).join(", ")}`);
      }

      if (search.country && location.includes(normalize(search.country))) {
        score += 8;
        reasons.push(`Location includes ${search.country}`);
      }

      if (search.remoteMode && job.remoteStatus === search.remoteMode) {
        score += 10;
        reasons.push(`Remote preference matched: ${search.remoteMode.toLowerCase()}`);
      }

      if (search.employmentType && job.jobType === search.employmentType) {
        score += 6;
      }

      if (search.salaryMin && (job.salaryMax ?? 0) >= search.salaryMin) {
        score += 4;
      }

      if (resumeSkills.length) {
        const unmatched = jobKeywords.filter((keyword) => !resumeSkills.some((skill) => skill.includes(keyword) || keyword.includes(skill)));
        missingKeywords.push(...unmatched.slice(0, 4));
      }

      return {
        ...job,
        matchScore: Math.max(0, Math.min(100, score)),
        matchReasons: reasons.slice(0, 4),
        missingKeywords: dedupe(missingKeywords).slice(0, 6)
      };
    })
    .sort((left, right) => right.matchScore - left.matchScore);
}
